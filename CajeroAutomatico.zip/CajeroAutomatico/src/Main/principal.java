package Main;
import Visual.Portada;


public class principal {
    
    public static void main(String[] args) {
        Portada p = new Portada();
        System.out.println("sopas");
        p.setVisible(true);
        
    }
    
}
